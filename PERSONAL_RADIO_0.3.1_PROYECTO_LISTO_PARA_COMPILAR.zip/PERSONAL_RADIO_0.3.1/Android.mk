LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)

LOCAL_CPP_EXTENSION := .cpp .cc
LOCAL_MODULE := PersonalRadio
LOCAL_SRC_FILES := main.cpp mod/logger.cpp mod/config.cpp

# AML oficial coloca los headers dentro de include/
LOCAL_C_INCLUDES := $(LOCAL_PATH)/include

LOCAL_CFLAGS += -O2 -mfloat-abi=softfp -DNDEBUG
LOCAL_CPPFLAGS += -std=c++17
LOCAL_CXXFLAGS += -std=c++17 -fexceptions
LOCAL_LDLIBS += -llog -ldl

include $(BUILD_SHARED_LIBRARY)
