# PERSONAL RADIO 0.3.1

Proyecto fuente para compilar el mod nativo de GTA San Andreas Android mediante GitHub Actions.

El workflow usa los headers oficiales de AndroidModLoader (RusJJ/AndroidModLoader) y el header de interfaz BASSMod. El resultado esperado es `libPersonalRadio.so` para `armeabi-v7a`.

Importante: este paquete contiene código fuente y configuración de compilación. No contiene todavía un `.so` compilado. La compilación de GitHub Actions debe ejecutarse y terminar correctamente para producirlo.
