# PERSONAL RADIO para GTA San Andreas Android 2.00

**Estado: prototipo nativo en desarrollo.** Objetivo de compilación: `armeabi-v7a` (GTA SA Android 2.00 de 32 bits), con Android Mod Loader (AML).

## Qué incluye esta primera compilación

- Reproductor de música local independiente de las emisoras originales.
- Búsqueda recursiva de archivos `.mp3`, `.ogg` y `.wav` en el almacenamiento compartido que el proceso de GTA SA tenga permitido leer.
- Orden aleatorio de las pistas.
- Controles táctiles superpuestos mientras el jugador está dentro de un vehículo: encender/apagar, anterior, pausa/reanudar y siguiente.
- No modifica los OBB ni sustituye archivos de audio del juego.

## Lo que todavía NO incluye

Esta versión no crea todavía una nueva entrada dentro del selector/carrusel original de emisoras. El prototipo utiliza controles propios en pantalla mientras se desarrolla esa integración. No debe anunciarse ni instalarse como si esa parte ya estuviera terminada.

## Dependencias

Requiere AML compatible con GTA SA Android 2.00 y el plugin **BASSMod** de AndroidModLoader, que proporciona la interfaz de audio `BASS`. BASSMod es una dependencia separada: este repositorio compila únicamente `libPersonalRadio.so` y no redistribuye el motor BASS ni su plugin.

## Compilación gratuita

El workflow `.github/workflows/build.yml` compila el mod usando Android NDK en GitHub Actions. Se inicia automáticamente con cada push a `main` o manualmente desde la pestaña **Actions**. El ZIP compilado aparece como artefacto de la ejecución cuando el trabajo termina correctamente. No se necesitan claves ni servicios de pago.

## Permisos de música en Android 11

El mod solo puede leer los archivos que Android permita leer al proceso del juego. Android 11 puede limitar el acceso directo al almacenamiento compartido según el `targetSdkVersion` y los permisos declarados por el APK. Si la búsqueda encuentra cero pistas, no significa necesariamente que no haya música: puede ser una restricción de acceso del APK. Este prototipo no modifica el APK ni solicita permisos nuevos.

## Instalación de prueba

No instales el código fuente ni el ZIP del proyecto. Cuando exista una compilación verificada, copia el archivo `.so` en la carpeta `mods` de AML. BASSMod debe estar instalado por separado en esa misma instalación de AML. Conserva intactos los archivos OBB y las emisoras originales. Durante la prueba, selecciona **Radio Off** en el selector normal para que no se mezclen dos fuentes de audio.

**Aviso:** la compilación del código no demuestra todavía compatibilidad funcional en tu dispositivo. Hace falta probar la carga de AML, el acceso a música y la reproducción en GTA SA 2.00 antes de darla por terminada.
